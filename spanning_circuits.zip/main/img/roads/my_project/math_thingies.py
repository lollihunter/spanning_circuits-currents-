def evaluate(x, difficulty):
    d = difficulty
    return int((1 + d/5) * x)